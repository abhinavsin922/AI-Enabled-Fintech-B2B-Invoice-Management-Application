package com.highradius;
//for checking executing
public class Add_jo {
	private String executionStatus;
	private String executionMessage;
	public String getExecutionStatus() {
		return executionStatus;
	}
	public void setExecutionStatus(String executionStatus) {
		this.executionStatus = executionStatus;
	}
	public String getExecutionMessage() {
		return executionMessage;
	}
	public void setExecutionMessage(String executionMessage) {
		this.executionMessage = executionMessage;
	}
}